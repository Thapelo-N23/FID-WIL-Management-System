# FID-WIL-Management-System
The FID WIL Management System is a digital platform designed to streamline the management of Work-Integrated Learning (WIL) activities within the Faculty of Informatics and Design (FID).
