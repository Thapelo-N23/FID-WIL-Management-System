package za.ac.cput.factory;

import za.ac.cput.domain.Course;
import za.ac.cput.domain.Coordinator;
import za.ac.cput.domain.Student;

import java.util.List;

public class CourseFactory {

    public static Course build(String courseName, Boolean status, Coordinator coordinator, List<Student> students) {
        if (courseName == null || courseName.isBlank()) {
            throw new IllegalArgumentException("Course name is required");
        }

        return new Course.Builder()
                .setCourseName(courseName)
                .setStatus(status != null ? status : true)
                .setCoordinator(coordinator)
                .setStudents(students)
                .build();
    }
}