package za.ac.cput.domain;

public enum Role {
    ADMIN,
    STUDENT,
    BUSINESS,
    COORDINATOR
}
