package za.ac.cput.domain;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "courses")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "course_id")
    private Long id;

    @Column(name = "course_name", nullable = false, length = 100)
    private String courseName;

    @Column(nullable = false)
    private Boolean status = true;

    @ManyToOne
    @JoinColumn(name = "coordinator_id")
    private Coordinator coordinator;

    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Student> students;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Constructors
    public Course() {}

    private Course(Builder builder) {
        this.id = builder.id;
        this.courseName = builder.courseName;
        this.status = builder.status;
        this.coordinator = builder.coordinator;
        this.students = builder.students;
        this.createdAt = builder.createdAt;
        this.updatedAt = builder.updatedAt;
    }

    // Getters
    public Long getId() { return id; }
    public String getCourseName() { return courseName; }
    public Boolean getStatus() { return status; }
    public Coordinator getCoordinator() { return coordinator; }
    public List<Student> getStudents() { return students; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    // Setters
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public void setStatus(Boolean status) { this.status = status; }
    public void setCoordinator(Coordinator coordinator) { this.coordinator = coordinator; }
    public void setStudents(List<Student> students) { this.students = students; }

    // Builder Class
    public static class Builder {
        private Long id;
        private String courseName;
        private Boolean status = true;
        private Coordinator coordinator;
        private List<Student> students;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;

        public Builder setId(Long id) {
            this.id = id;
            return this;
        }

        public Builder setCourseName(String courseName) {
            this.courseName = courseName;
            return this;
        }

        public Builder setStatus(Boolean status) {
            this.status = status;
            return this;
        }

        public Builder setCoordinator(Coordinator coordinator) {
            this.coordinator = coordinator;
            return this;
        }

        public Builder setStudents(List<Student> students) {
            this.students = students;
            return this;
        }

        public Builder setCreatedAt(LocalDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder setUpdatedAt(LocalDateTime updatedAt) {
            this.updatedAt = updatedAt;
            return this;
        }

        public Builder copy(Course course) {
            this.id = course.id;
            this.courseName = course.courseName;
            this.status = course.status;
            this.coordinator = course.coordinator;
            this.students = course.students;
            this.createdAt = course.createdAt;
            this.updatedAt = course.updatedAt;
            return this;
        }

        public Course build() {
            return new Course(this);
        }
    }

    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", courseName='" + courseName + '\'' +
                ", status=" + status +
                ", coordinator=" + (coordinator != null ? coordinator.getId() : "null") +
                ", students=" + (students != null ? students.size() : 0) +
                '}';
    }
}